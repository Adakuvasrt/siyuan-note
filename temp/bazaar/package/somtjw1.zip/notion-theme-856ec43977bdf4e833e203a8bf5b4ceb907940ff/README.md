# notion复刻版
适用版本：思源笔记 v1.3.6
需要搭配复刻图标使用：https://github.com/royc01/notion-icon
![preview](https://raw.githubusercontent.com/royc01/notion-theme/main/preview.png)
*********
修改头图添加方式
*********
更新隐藏工具栏方式
*********
调整整体结构
设置栏改到右侧
适配PDF标注特性
没有子文档的文档前加标识
*********
修正上下文图标问题
修改表格样式
*********
修正自定义图标
修正边栏被压缩问题
*********
