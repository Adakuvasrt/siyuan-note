# siyuan-icon
![preview](https://raw.githubusercontent.com/materium/materium-siyuan-icon/terra/preview.png)
